const mongoose = require('mongoose');

const attachmentSchema = new mongoose.Schema({
  filename: { type: String, required: true },
  contentType: { type: String, required: true },
  data: { type: Buffer, required: true },
});

const emailSchema = new mongoose.Schema({
  sender: { type: String, required: true },
  recipient: { type: String, required: true },
  subject: { type: String, required: true },
  content: { type: String, required: true },
  timestamp: { type: Date, required: true },
  replied: { type: Boolean, default: false },
  forwarded: { type: Boolean, default: false },
  originalEmailId: { type: mongoose.Schema.Types.ObjectId, ref: 'Email' },
  attachments: [attachmentSchema],  // New field for attachments
});

const Email = mongoose.model('Email', emailSchema);

module.exports = Email;
