const errorHandlerMiddleware = (err, req, res, next) => {
    console.error(err.stack);
  
    let statusCode;
    let responseMessage;

    // Map error status codes to custom messages
    switch (err.status) {
        case 100:
            statusCode = 100;
            responseMessage = 'Continue: The initial part of the request has been received, and the client should proceed to send the remainder of the request.';
            break;
        case 200:
            statusCode = 200;
            responseMessage = 'OK: The request was successful, and the server has returned the requested data.';
            break;
        case 201:
            statusCode = 201;
            responseMessage = 'Created: The request was successful, and a new resource was created as a result.';
            break;
        case 301:
            statusCode = 301;
            responseMessage = 'Moved Permanently: The requested resource has been permanently moved to a different location.';
            break;
        case 400:
            statusCode = 400;
            responseMessage = 'Bad Request: The request could not be understood or was missing required parameters.';
            break;
        case 401:
            statusCode = 401;
            responseMessage = 'Unauthorized: Authentication is required and has failed or has not been provided.';
            break;
        case 404:
            statusCode = 404;
            responseMessage = 'Not Found: The requested resource could not be found on the server.';
            break;
        case 500:
            statusCode = 500;
            responseMessage = 'Internal Server Error: An unexpected condition was encountered on the server, preventing it from fulfilling the request.';
            break;
        case 503:
            statusCode = 503;
            responseMessage = 'Service Unavailable: The server is not ready to handle the request. Common causes are a server undergoing maintenance or being overloaded.';
            break;
        default:
            statusCode = 500; // Default to Internal Server Error
            responseMessage = 'Internal Server Error: An unexpected error occurred.';
    }

    // Send the response
    res.status(statusCode).json({ error: responseMessage });
};

module.exports = errorHandlerMiddleware;
