const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const User = require('../models/userModel');
const dotenv = require('dotenv');

dotenv.config();

const secretKey = process.env.JWT_SECRET_KEY;

// Middleware to generate a JWT token upon successful login
const generateToken = async (req, res, next) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ email });

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const passwordMatch = await bcrypt.compare(password, user.password);

    if (passwordMatch) {
      const token = jwt.sign(
        { userId: user._id, username: user.username, email: user.email },
        secretKey,
        { expiresIn: '2h' }
      );

      res.locals.token = token;
      res.locals.user = user;
      res.locals.email= email;
      console.log(user)

      next();
    } else {
      res.status(401).json({ error: 'Invalid password' });
    }
  } catch (error) {
    console.error('Error generating token:', error.message);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Middleware to verify a JWT token
const verifyToken = (req, res, next) => {
  const token = req.headers.authorization;

  if (!token || !token.startsWith('Bearer ')) {
    console.log('Token is missing or invalid');
    return res.status(401).json({ error: 'Unauthorized: Missing or invalid token' });
  }

  const tokenWithoutBearer = token.substring('Bearer '.length);

  try {
    const decodedPayload = jwt.verify(tokenWithoutBearer, secretKey);
    req.user = decodedPayload;
    
    console.log("decoded payload:", decodedPayload);
    module.exports.decodedPayload = decodedPayload;
    next();
  } catch (err) {
    console.error('Token Verification Error:', err.message);

    if (err.name === 'JsonWebTokenError') {
      return res.status(401).json({ error: 'Unauthorized: Invalid token' });
    } else if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Unauthorized: Token expired' });
    }

    res.status(401).json({ error: 'Unauthorized: Invalid token' });
  }
};
const getCurrentUser = async (req, res, next) => {
  try {
    // Get the decoded user information from the request
    const decoded = req.user;
    console.log("decodec log:",decoded)

    // Find the user by the decoded user ID
    const currentUser = await User.findById(decoded.userId);

    if (!currentUser) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Attach the user object to the request for future use
    req.user = currentUser;

    next(); // Continue with the next middleware or route handler
  } catch (error) {
    console.error(error);
    res.status(401).json({ error: 'Unauthorized' });
  }
};

module.exports = {
  generateToken,
  verifyToken,
  getCurrentUser
};
