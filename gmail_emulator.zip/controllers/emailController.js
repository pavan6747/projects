// emailController.js
const Email = require('../models/emailModel'); // Update the path accordingly
const { getCurrentUser } = require('../middleware/authMiddleware');
const fs = require('fs');
const path = require('path');
const stream = require('stream');
const errorHandlerMiddleware = require('../middleware/errorHandlerMiddleware');


// Create a new email
exports.createEmail = async (req, res) => {
  try {
    console.log('Incoming Request:', req.body);

    console.log('Received form data:', req.body);
    console.log('Received files:', req.files);
    // Use getCurrentUser middleware to get the current user
    await getCurrentUser(req, res, async () => {
      // Now you can access req.user.email
      const senderEmail = req.user.email;
      
      // Check if recipients array is provided in the request body
      const recipientEmails = Array.isArray(req.body.recipients)
        ? req.body.recipients
        : [req.body.recipients];

      // Check if the content field is provided in the request body
      if (!req.body.content) {
        return res.status(400).json({ error: 'Please provide the email content' });
      }

      // Extract attachments from the form-data
      const attachments = req.files.map(file => ({
        filename: file.originalname,
        contentType: file.mimetype,
        data: file.buffer,
      }));
      console.log('attachments:',attachments);

      // Add the current timestamp, sender, and content to each recipient's email data
      const emailDataArray = recipientEmails.map(recipientEmail => ({
        sender: senderEmail,
        recipient: recipientEmail,
        subject: req.body.subject || '',
        content: req.body.content,
        timestamp: Date.now(),
        attachments: attachments,
      }));

      // Create new email instances for each recipient
      const newEmails = await Email.create(emailDataArray);
      console.log("emailDataArray",emailDataArray)

      res.status(201).json(newEmails);
    });
  } catch (error) {
    console.error(error);
    next(error)
  }
};
// Get all emails
exports.getAllEmails = async (req, res) => {
  try {
    const emails = await Email.find();
    res.status(200).json(emails);
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

// Get a specific email by ID
exports.getEmailById = async (req, res) => {
  try {
    const email = await Email.findById(req.params.id);
    if (!email) {
      return res.status(404).json({ error: 'Email not found' });
    }
    res.status(200).json(email);
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

// Update an email by ID
exports.updateEmailById = async (req, res) => {
  try {
    const updatedEmail = await Email.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!updatedEmail) {
      return res.status(404).json({ error: 'Email not found' });
    }
    res.status(200).json(updatedEmail);
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

// Delete an email by ID
exports.deleteEmailById = async (req, res) => {
  try {
    const deletedEmail = await Email.findByIdAndDelete(req.params.id);
    if (!deletedEmail) {
      return res.status(404).json({ error: 'Email not found' });
    }
    res.status(204).send(); // No content on successful deletion
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }
};
exports.replyToEmailById = async (req, res) => {
  try {
    const originalEmail = await Email.findById(req.params.id);
    if (!originalEmail) {
      return res.status(404).json({ error: 'Original email not found' });
    }

    // Use getCurrentUser middleware to get the current user
    await getCurrentUser(req, res, async () => {
      // Now you can access req.user.email
      const senderEmail = req.user.email;

      const replyData = {
        sender: senderEmail,
        recipient: originalEmail.sender, // Reply to the original sender
        subject: `Orginal Mail: ${originalEmail.subject}\nReply:${req.body.subject}`,
        content: `Content:${originalEmail.
          content}\n RepliedContent:${req.body.content}`,
        // Exclude the 'body' field when replying
        timestamp: Date.now(),
        replied: true,
        originalEmailId: originalEmail._id,
      };

      const replyEmail = await Email.create(replyData);

      res.status(201).json(replyEmail);
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

// Forward an email by ID
exports.forwardEmailById = async (req, res) => {
  try {
    const originalEmail = await Email.findById(req.params.id);
    if (!originalEmail) {
      return res.status(404).json({ error: 'Original email not found' });
    }

    // Check if recipients array is provided in the request body
    if (!req.body.recipients || !Array.isArray(req.body.recipients) || req.body.recipients.length === 0) {
      return res.status(400).json({ error: 'Please provide a valid array of recipients for forwarding' });
    }

    // Use getCurrentUser middleware to get the current user
    await getCurrentUser(req, res, async () => {
      // Now you can access req.user.email
      const senderEmail = req.user.email;

      const forwardDataArray = req.body.recipients.map(recipientEmail => ({
        sender: senderEmail,
        recipient: recipientEmail,
        subject: `Fwd: ${originalEmail.subject}\nchanges:${req.body.subject}`,
        content: `[Forwarded from ${senderEmail}]\n\n${originalEmail.
          content}\nchanges:${req.body.content}`,
        // Exclude the 'body' field when forwarding
        timestamp: Date.now(),
        forwarded: true,
        originalEmailId: originalEmail._id,
      }));

      const forwardedEmails = await Email.create(forwardDataArray);

      res.status(201).json(forwardedEmails);
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};
exports.downloadAttachments = async (req, res) => {
  try {
    // Get email ID from request parameters
    const emailId = req.params.id;

    // Retrieve the email from the database
    const email = await Email.findById(emailId);

    // Ensure the email is found
    if (!email) {
      return res.status(404).json({ error: 'Email not found' });
    }

    // Check if there are attachments
    if (!email.attachments || email.attachments.length === 0) {
      return res.status(404).json({ error: 'No attachments found for this email' });
    }

    // Set the common response headers for download
    res.setHeader('Content-disposition', 'attachment');

    // Specify the folder where attachments will be saved
    const folderPath = path.join(__dirname, 'files');

    // Create the folder if it doesn't exist
    if (!fs.existsSync(folderPath)) {
      fs.mkdirSync(folderPath);
    }

    // Loop through all attachments and download each
    for (const attachment of email.attachments) {
      // Set headers for each attachment
      res.setHeader('Content-filename', attachment.filename);
      res.setHeader('Content-type', attachment.contentType);

      // Create a read stream for the specific attachment
      const fileStream = new stream.PassThrough();
      fileStream.end(attachment.data);

      // Pipe the file stream to the response
      fileStream.pipe(res);

      // Save the file to the specified folder
      const filePath = path.join(folderPath, attachment.filename);
      const writeStream = fs.createWriteStream(filePath);
      fileStream.pipe(writeStream);
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};