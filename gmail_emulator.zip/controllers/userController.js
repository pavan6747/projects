const bcrypt = require('bcrypt');
const User = require('../models/userModel');
const { generateToken,decodedPayload,getCurrentUser} = require('../middleware/authMiddleware');


// Controller function to handle user registration
const registerUser = async (req, res) => {
  try {
    const { username, password, phoneNumber, email } = req.body;

    // Hash the password before saving it to the database
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create a new user with the hashed password
    const newUser = new User({ username, password: hashedPassword, phoneNumber, email });
    const savedUser = await newUser.save();

    res.status(201).json({ message: 'User registered successfully', user: savedUser });
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Controller function to handle user sign in
const signInUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find the user by email
    const user = await User.findOne({ email });

    // If the user is not found, return an error
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Compare the entered password with the hashed password in the database
    const passwordMatch = await bcrypt.compare(password, user.password);

    // If passwords match, user is authenticated; otherwise, return an error
    if (passwordMatch) {
      generateToken(req, res, () => {
        res.status(200).json({ message: 'User signed in successfully', token: res.locals.token });
        console.log("login Token:",res.locals.token)
        
      });
      
    } else {
      res.status(401).json({ error: 'Invalid password' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
};



// Controller function to handle user update
const updateUser = async (req, res) => {
  try {
    const { id } = req.params;
    const { username, phoneNumber, email } = req.body;

    // Find the user by ID and update the fields
    const updatedUser = await User.findByIdAndUpdate(
      id,
      { username, phoneNumber, email },
      { new: true } // Return the updated document
    );

    // If the user is not found, return an error
    if (!updatedUser) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.status(200).json({ message: 'User updated successfully', user: updatedUser });
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Controller function to handle user deletion
const deleteUser = async (req, res) => {
  try {
    const { id } = req.params;

    // Find the user by ID and delete it
    const deletedUser = await User.findByIdAndDelete(id);

    // If the user is not found, return an error
    if (!deletedUser) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.status(200).json({ message: 'User deleted successfully', user: deletedUser });
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Add other controller functions as needed

module.exports = {
  registerUser,
  signInUser,
  updateUser,
  deleteUser,
  
  // Add other exported controller functions here
};
