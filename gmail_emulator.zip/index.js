// index.js
const express = require('express');
const bodyParser = require('body-parser');
const connectDB = require('./db');
const userRoutes = require('./routes/userRoutes')
const emailRoutes = require('./routes/emailRoutes')
const {verifyToken} = require('./middleware/authMiddleware')
const multer = require('multer')
const upload = multer()

const app = express();
const port = 3000;


app.use(upload.any());
app.use(bodyParser.json());
app.use('/', userRoutes);
app.use('/',verifyToken, emailRoutes);



connectDB();
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
