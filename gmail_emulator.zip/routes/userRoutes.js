const express = require('express');
const userController = require('../controllers/userController');
const { verifyToken, generateToken, getCurrentUser } = require('../middleware/authMiddleware');  // Add getCurrentUser

const router = express.Router();

// Route to handle user registration
router.post('/register', userController.registerUser);

// Route to handle user sign in
router.post('/login', generateToken, userController.signInUser,getCurrentUser);

// Route to handle user update
router.put('/:id', verifyToken, getCurrentUser, userController.updateUser);

// Route to handle user deletion
router.delete('/:id', verifyToken, getCurrentUser, userController.deleteUser);

// Add other routes as needed

module.exports = router;
